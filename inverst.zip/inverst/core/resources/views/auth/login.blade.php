<!DOCTYPE html>
<html dir="ltr" lang="en">

<!-- Mirrored from html.kodesolution.live/s/cryptopress/v3.0/demo/form-login-style2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 23 Sep 2020 13:33:01 GMT -->
<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="CryptoPress - Cryptocurrency Responsive HTML5 Template" />
<meta name="keywords" content="bitcoin, blockchain, coin currency, crypto currency, currency, Currency Exchange, digital currency, exchange, exchange currency,litecoin, online wallet," />
<meta name="author" content="ThemeMascot" />

<!-- Page Title -->
<title>{{ $site_title }} | {{ $page_title }}</title>

<!-- Favicon and Touch Icons -->
<link href="{{ asset('assets/newfront/images/favicon.png') }}" rel="shortcut icon" type="image/png">
<link href="{{ asset('assets/newfront/images/apple-touch-icon.png') }}" rel="apple-touch-icon">
<link href="{{ asset('assets/newfront/images/apple-touch-icon-72x72.png') }}" rel="apple-touch-icon" sizes="72x72">
<link href="{{ asset('assets/newfront/images/apple-touch-icon-114x114.png') }}" rel="apple-touch-icon" sizes="114x114">
<link href="{{ asset('assets/newfront/images/apple-touch-icon-144x144.png') }}" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="{{ asset('assets/newfront/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('assets/newfront/css/jquery-ui.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('assets/newfront/css/animate.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('assets/newfront/css/css-plugin-collections.css') }}" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link href="{{ asset('assets/newfront/css/menuzord-megamenu.css') }}" rel="stylesheet"/>
<link id="{{ asset('assets/newfront/menuzord-menu-skins') }}" href="css/menuzord-skins/menuzord-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="{{ asset('assets/newfront/css/style-main.css') }}" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="{{ asset('assets/newfront/css/preloader.css') }}" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="{{ asset('assets/newfront/css/custom-bootstrap-margin-padding.css') }}" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="{{ asset('assets/newfront/css/responsive.css') }}" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- CSS | Theme Color -->
<link href="{{ asset('assets/newfront/css/colors/theme-skin-color-set2.css') }}" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="{{ asset('assets/newfront/js/jquery-2.2.4.min.js') }}"></script>
<script src="{{ asset('assets/newfront/js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('assets/newfront/js/bootstrap.min.js') }}"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="{{ asset('assets/newfront/js/jquery-plugin-collection.js') }}"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="">
<div id="wrapper" class="clearfix">
  <!-- preloader -->
  <div id="preloader">
    <div id="spinner">
      <div class="preloader-dot-loading">
        <div class="cssload-loading"><i></i><i></i><i></i><i></i></div>
      </div>
    </div>
    <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
  </div>

  <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: home -->
    <section id="home" class="divider parallax fullscreen layer-overlay overlay-dark-9" data-bg-img="{{ asset('assets/newfront/images/bg/bg1.jpg') }}">
      <div class="display-table">
        <div class="display-table-cell">
          <div class="container">
            <div class="row">
              <div class="col-md-6 col-md-push-3">
                <div class="text-center mb-60"><a href="{{ route('home') }}" class=""><img alt="" src="{{ asset('assets/newfront/images/logo-wide.png') }}"></a></div>
                <h2 class="text-white text-center mt-0 pt-5"> Login</h2>
                @if($errors->any())
                        
                <div class=" alert text-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    @foreach ($errors->all() as $error)
                    {!!  $error !!}
                    @endforeach
                </div>
                
                @endif

                @if (session()->has('message'))
                    <div class="alert text-{{ session()->get('type') }} alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        {{ session()->get('message') }}
                    </div>
                @endif
                
                @if (session()->has('status'))
                    <div class="alert text-danger  alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        {{ session()->get('status') }}
                    </div>
                @endif
                <form  name="login-form" class="form-transparent clearfix"  method="POST" action="{{ route('login') }}">
                    {{ csrf_field() }}
                  <div class="row">
                    <div class="form-group col-md-12">
                      <label class = "text-white" for="form_username_email">Username</label>
                      <input name="username" id="username"  class="form-control" required type="text">
                    </div>
                  </div>
                  <div class="row">
                    <div class="form-group col-md-12">
                      <label class ="text-white" for="form_password">Password</label>
                      <input name="password" id="password" required class="form-control" type="password">
                    </div>
                  </div>
                  <div class="clear text-center pt-10">
                    <a class="text-white font-weight-600 font-12" href="{{ route('password.request') }}">Forgot Your Password?</a>
                  </div>
                  <div class="clear text-center pt-10">
                    <button class="btn btn-dark btn-lg btn-block no-border mt-15 mb-15" type="submit">login</button>
                    <span class = "text-white">OR</span>
                    <a class="btn btn-dark btn-lg btn-block no-border" href="{{ route('register') }}" data-bg-color="green">Register</a>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content --> 

  <!-- Footer -->
  <footer id="footer" class="footer bg-black-111">
    <div class="container p-20">
      <div class="row">
        <div class="col-md-12 text-center">
          <p class="mb-0">{!! $basic->copy_text !!}</p>
        </div>
      </div>
    </div>
  </footer>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

 
<script src="{{ asset('assets/newfront/js/custom.js') }}"></script>

<!-- <script src="{{ asset('assets/js/main.js') }}"></script> -->
<!--swal alert message-->
@if (session('success'))
    <script type="text/javascript">
        $(document).ready(function(){
            swal("Success!", "{{ session('success') }}", "success");
        });
    </script>
@endif
@if (session('alert'))
    <script type="text/javascript">
        $(document).ready(function(){
            swal("Sorry!", "{{ session('alert') }}", "error");
        });
    </script>
@endif
@if (session('error'))
    <script type="text/javascript">
        $(document).ready(function(){
            swal("Sorry!", "{{ session('error') }}", "error");
        });
    </script>
@endif

<!--end swal alert message-->
<script>
var mobile = (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent));

hljs.initHighlightingOnLoad();
hljs.configure({useBR: true});
jQuery('#raindrops').raindrops({color:'#fff',canvasHeight:5});
jQuery('#raindrops-green').raindrops({color:'#{{$basic->color}} ',canvasHeight:5});

</script>
<script>
function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
    document.getElementById("click").innerHTML = "Hide";
  } else {
    x.type = "password";
    document.getElementById("click").innerHTML = "Show";
  }
}
</script>
</body>
</html>
