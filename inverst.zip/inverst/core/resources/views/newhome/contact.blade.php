@extends('layouts.newfrontend')
@section('content')
    <!-- Start main-content -->
  <div class="main-content">

<!-- Section: home -->
   <!-- Section: inner-header -->
   <section class="inner-header divider layer-overlay overlay-dark-6" data-bg-img="{{ asset('assets/newfront/images/bg/bg17.jpg') }}">
    <div class="container pt-120 pb-60">
      <!-- Section Content -->
      <div class="section-content">
        <div class="row"> 
          <div class="col-md-6">
            <h2 class="text-theme-colored2 font-36">CONTACT</h2>
            <ol class="breadcrumb text-left mt-10 white">
              <li><a href="{{ route('contact') }}">CONTACT</a></li>
              <li><a href="{{ route('contact') }}">CONTACT US</a></li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  </section>

<!-- Section: Intro -->
<section class="bg-lighter">
  <div class="container">
    <div class="section-content text-center">
        <div class="row">
          
            <!-- Start main-content -->
<div class="main-content">
<!-- Section: home -->
<section id="home" class="divider parallax layer-overlay overlay-dark-9" data-bg-img="{{ asset('assets/newfront/images/bg/bg1.jpg') }}">
  <div class="display-table">
    <div class="display-table-cell">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-md-push-3">
            <div class="text-center mb-60"></div>
            <div class="widget bg-lightest border-1px p-30">
              <div class="widget border-1px p-30">
                <h5 class="widget-title line-bottom">Contact Us</h5>
                @if($errors->any())
                            
                    <div class=" alert text-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        @foreach ($errors->all() as $error)
                        {!!  $error !!}
                            @endforeach
                    </div>
                    
                @endif
                @if (session()->has('message'))
                    <div class="alert text-{{ session()->get('type') }} alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        {{ session()->get('message') }}
                    </div>
                @endif
                <form id="quick_contact_form" name="quick_contact_form" class="quick-contact-form" action="{{ route('contact-submit') }}" method="post">
                    {!! csrf_field() !!}
                  <div class="form-group">
                    <input name="name" id="firstname" class="form-control" type="text" required="" placeholder="Enter Name">
                  </div>
                  <div class="form-group">
                    <input name="phone" id="phone" class="form-control" type="text" required="" placeholder="Enter Phone number">
                  </div>
                  <div class="form-group">
                    <input name="email" id="email" class="form-control" type="text" required="" placeholder="Enter Email">
                  </div>
                  <div class="form-group">
                    <input name="subject" id="subject" class="form-control" type="text" required="" placeholder="Subject">
                  </div>
                  <div class="form-group">
                    <textarea id="message" name="message" class="form-control" required="" placeholder="Enter Message" rows="3"></textarea>
                  </div>
                  <div class="form-group">
                    <input name="form_botcheck" class="form-control" type="hidden" value="" />
                    <button type="submit" class="btn btn-dark btn-theme-colored btn-sm mt-0" data-loading-text="Please wait...">Send Message</button>
                  </div>
                </form>

                <!-- Quick Contact Form Validation-->
                <script type="text/javascript">
                  $("#quick_contact_form").validate({
                    submitHandler: function(form) {
                      var form_btn = $(form).find('button[type="submit"]');
                      var form_result_div = '#form-result';
                      $(form_result_div).remove();
                      form_btn.before('<div id="form-result" class="alert alert-success" role="alert" style="display: none;"></div>');
                      var form_btn_old_msg = form_btn.html();
                      form_btn.html(form_btn.prop('disabled', true).data("loading-text"));
                      $(form).ajaxSubmit({
                        dataType:  'json',
                        success: function(data) {
                          if( data.status == 'true' ) {
                            $(form).find('.form-control').val('');
                          }
                          form_btn.prop('disabled', false).html(form_btn_old_msg);
                          $(form_result_div).html(data.message).fadeIn('slow');
                          setTimeout(function(){ $(form_result_div).fadeOut('slow') }, 6000);
                        }
                      });
                    }
                  });
                </script>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 
</div>  
<!-- end main-content -->

          </div>
        </div>
    </div>
  </div>
</section>


          <!-- JS | Chart-->
          <script src="js/chart.js"></script>
          <!-- <img src="images/services/1.png" alt=""> -->
        </div>
      </div>
    </div>
  </div>
</section>

  
@endsection