@extends('layouts.newfrontend')
@section('content')

   <!-- Start main-content -->
   <div class="main-content">

<!-- Section: home -->
   <!-- Section: inner-header -->
   <section class="inner-header divider layer-overlay overlay-dark-6" data-bg-img="{{ asset('assets/newfront/images/bg/bg17.jpg') }}">
    <div class="container pt-120 pb-60">
      <!-- Section Content -->
      <div class="section-content">
        <div class="row"> 
          <div class="col-md-6">
            <h2 class="text-theme-colored2 font-36">FAQs</h2>
            <ol class="breadcrumb text-left mt-10 white">
              <li><a href="{{ route('faqs') }}">FAQ</a></li>
              <li><a href="{{ route('faqs') }}">FREQUENTLY ASKED QUESTIONS</a></li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  </section>

<!-- Section: Intro -->
<section class="bg-lighter">
  <div class="container">
    <div class="section-content text-center">
        <div class="row">
          
            <!-- Start main-content -->
<div class="main-content">
<!-- Section: home -->

<section class="position-inherit">
    <div class="container">
      <div class="row">
        <div class="col-md-3 scrolltofixed-container">
          <div class="list-group scrolltofixed z-index-0">
          @foreach($faqs as $key => $f)
            <a href="#domainsTabQ{{ $f->id }}" class="list-group-item smooth-scroll-to-target">{{ $f->title }} ?</a>
            @endforeach
          </div>
        </div>
        <div class="col-md-9">
        @foreach($faqs as $key => $f)
          <div id="domainsTabQ{{ $f->id }}" class="mb-50">
            <h3>{{ $f->title }} ?</h3>
            <hr>
            <p class="mb-20">{!!  $f->description !!}</p>
          </div>

          @endforeach

   
        </div>
      </div>
    </div>
  </section> 
</div>  
<!-- end main-content -->

          </div>
        </div>
    </div>
  </div>
</section>


          <!-- JS | Chart-->
          <script src="js/chart.js"></script>
          <!-- <img src="images/services/1.png" alt=""> -->
        </div>
      </div>
    </div>
  </div>
</section>



   

@endsection