@extends('layouts.user-frontend.user-dashboard')
@section('content')

@include('layouts.breadcam')

<div class="content_padding">
    <div class="container user-dashboard-body">
    <div class="row">
        <div class="login-admin login-admin1">
            <div class="login-header text-center">
                 <div class="container">
                <div class="row">
                     <div class="col-xs-12">
                        <h3 class="title-about risk-title">Change Password</h3>
                    </div>
                </div>
                
            </div>
            </div>
        
            <div class="col-md-6 col-md-offset-3">

                 <!-- Form Starts -->
                       {!! Form::open(['method'=>'post','role'=>'form','class'=>'form-horizontal']) !!}
                            {{ csrf_field() }}
                            <!-- Input Field Starts -->
                            <div class="form-group">
                                <input class="form-control" name="current_password" id="current_password" placeholder="Current Password" type="password">
                            </div><br>
                            <!-- Input Field Ends -->
                            <!-- Input Field Starts -->
                            <div class="form-group">
                                <input class="form-control" name="password" id="password" placeholder="New Password" type="password">
                            </div><br>

                            <div class="form-group">
                                <input class="form-control" name="password_confirmation" id="password_confirmation" placeholder="New Password Again" type="password">
                            </div><br>
                            <!-- Input Field Ends -->
                            <!-- Submit Form Button Starts -->
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit">Change Password</button>
                    
                            </div>
                            <!-- Submit Form Button Ends -->
                        </form>
                        <!-- Form Ends -->
            </div>
        </div><!---ROW-->
    </div>
    </div>
</div>
@endsection

@section('script')
    @if (session('message'))

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Success!", "{{ session('message') }}", "success");

            });

        </script>

    @endif



    @if (session('alert'))

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Sorry!", "{{ session('alert') }}", "error");

            });

        </script>

    @endif
@endsection
