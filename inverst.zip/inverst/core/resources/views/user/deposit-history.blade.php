@extends('layouts.user-frontend.user-dashboard')
@section('content')
@include('layouts.breadcam')



<section class="services">
        
              <!--Start section-->
            <div class="container">
                <div class="row">
                    <!-- Purchased Products Starts -->
                    <div class="col-xs-12 table-responsive">
                        <table class="table order " id="sample_1" style="width:100%">
                            <thead>
                                <tr>
                                     <th>ID#</th>
                                    <th>Deposit Date</th>
                                    <th>Transaction ID</th>
                                    <th>Deposit Method</th>
                                    <th>Send Amount</th>
                                    <th>Deposit Charge</th>
                                    <th>Deposit Balance</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                           @php $i=0;@endphp
                        @foreach($deposit as $p)
                            @php $i++;@endphp
                            <tr>
                                <td>{{ $i }}</td>
                                <td>{{ date('d-F-Y h:i A',strtotime($p->created_at))  }}</td>
                                <td>{{ $p->transaction_id }}</td>
                                <td>
                                    @if($p->payment_type == 1)
                                        <span class="label bold label-primary"><i class="fa fa-paypal"></i> Paypal</span>
                                    @elseif($p->payment_type == 2)
                                        <span class="label bold label-primary"><i class="fa fa-money"></i> Perfect Money</span>
                                    @elseif($p->payment_type == 3)
                                        <span class="label bold label-primary"><i class="fa fa-btc"></i> BTC - BlockChain</span>
                                    @elseif($p->payment_type == 4)
                                        <span class="label bold label-primary"><i class="fa fa-cc-stripe"></i> Credit Card</span>
                                    @elseif($p->payment_type == 5)
                                        <span class="label bold label-primary"><i class="fa fa-compass"></i> Coin Paymnet</span>
                                    @elseif($p->payment_type == 6)
                                        <span class="label bold label-primary"><i class="fa fa-money"></i> Skrill</span>
                                    @else
                                        <span class="label bold label-primary"><i class="fa fa-bank"></i> {{ $p->bank->name }}</span>
                                    @endif
                                </td>
                                <td>
                                    @if($p->payment_type == 1 or $p->payment_type == 2 or $p->payment_type == 3 or $p->payment_type == 4)
                                        {{ round(($p->net_amount / $p->rate),$basic->deci) }} - USD
                                    @else
                                        {{ $p->net_amount }} - {{ $basic->currency }}
                                    @endif
                                </td>
                                <td>
                                    @if($p->payment_type == 1 or $p->payment_type == 2 or $p->payment_type == 3 or $p->payment_type == 4)
                                        {{ round(($p->charge / $p->rate),$basic->deci) }} - USD
                                    @else
                                        {{ $p->charge }} - {{ $basic->currency }}
                                    @endif
                                </td>
                                <td>
                                    @if($p->payment_type == 1 or $p->payment_type == 2 or $p->payment_type == 3 or $p->payment_type == 4)
                                        {{ $p->amount }} - {{ $basic->currency }}
                                    @else
                                        {{ $p->amount }} - {{ $basic->currency }}
                                    @endif
                                </td>
                                <td>
                                    @if($p->status == 1)
                                        <span class="label bold label-primary"><i class="fa fa-check"></i> Completed</span>
                                    @elseif($p->status == 0)
                                        <span class="label bold label-warning"><i class="fa fa-spinner"></i> Pending</span>
                                    @elseif($p->status == 2)
                                        <span class="label bold label-danger"><i class="fa fa-times"></i> Cancel</span>
                                    @endif
                                </td>

                            </tr>
                        @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- Purchased Products Ends -->
                   
                </div>
            </div>

            <br>

</section>


  @endsection
