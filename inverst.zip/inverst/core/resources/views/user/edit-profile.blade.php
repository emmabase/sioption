@extends('layouts.user-frontend.user-dashboard')

@section('style')
    <link href="{{ asset('assets/admin/css/bootstrap-fileinput.css') }}" rel="stylesheet">

    <style>
        input[type="text"] {
            width: 100%;
        }

        input[type="email"] {
            wi
        }
    </style>
@endsection
@section('content')
@include('layouts.breadcam')

<section id="pricing" class="bg-lighter">
  <div class="container pb-70 pb-sm-30">

   
         
             {!! Form::open(['method'=>'post','role'=>'form','class'=>'form-horizontal','files'=>true]) !!}
            <div class="row">
                <div class="col-md-3">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="fileinput fileinput-new" data-provides="fileinput">
                            <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;" data-trigger="fileinput">
                                <img style="width: 200px" src="{{ asset('assets/images') }}/{{ $user->image }}" alt="...">
                            </div>
                            <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
                            
                            <div class="img-input-div">
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="image" accept="image/*">
                                                </span>
                                <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-9">
                        <div class="col-md-6">
                            <div class="form-group">
                             <label class="col-md-12">
                                <strong style="text-transform: uppercase;">Name :</strong>
                            </label>
                            <input class="form-control" type="text" name="name" id="" value="{{ $user->name }}"  required placeholder="Name">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-md-12"><strong style="text-transform: uppercase;">User Name :</strong></label>
                                
                                <input class="form-control" type="text" name="username" id="" value="{{ $user->username }}" required placeholder="Username">
                                
                            </div>
                        </div>

                        <div class="col-md-6">
                              <div class="form-group">
                                <label class="col-md-12"><strong style="text-transform: uppercase;">Email :</strong></label>
                               
                                <input class="form-control" type="email" name="email" id="" value="{{ $user->email }}" required placeholder="Email">
                            </div>
                        </div>
                        <div class="col-md-6">
                             <div class="form-group">
                                <label class="col-md-12"><strong style="text-transform: uppercase;">Phone :</strong></label>
                                <input class="form-control" type="text" name="phone" id="" value="{{ $user->phone }}" required placeholder="Phone">
                            </div>

                        </div>
                        <div class="col-md-6">
                             <div class="form-group">
                                <label class="col-md-12"><strong style="text-transform: uppercase;">Country :</strong></label>
        <select id="" name="country" value="{{ $user->country }}" class="form-control">
                <option value="">Choose your country </option>
                 @foreach ($countries as $country)
                    <option  value="{{ $country }}"
                    @if ($user->country == $country)
                        selected="selected"
                    @endif
                    > {{ $country }}</option>
                @endforeach 
                
        </select>
                    </div>
                </div>
                 <div class="col-md-9">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-send"></i> UPDATE PROFILE</button>
                    </div>
                </div>
                
            </div>
           
    {!! Form::close() !!}
    </div>
</div>

</div>
</section>
@endsection

@section('script')
    <script src="{{ asset('assets/admin/js/bootstrap-fileinput.js') }}"></script>

    @if (session('message'))

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Success!", "{{ session('message') }}", "success");

            });

        </script>

    @endif

    @if (session('alert'))

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Sorry!", "{!! session('alert') !!}", "error");

            });

        </script>

    @endif

