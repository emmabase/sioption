@extends('layouts.user-frontend.user-dashboard')
@section('style')

<style>
    .input-text-box{
    border: 1px solid black;
    }
</style>

@endsection
@section('content')
@include('layouts.breadcam')


 <!-- Contact Section Starts -->
        <section class="contact">
            <div class="container">
                <div class="row">
                     <!-- Contact Widget Starts -->
                    <div class="col-xs-12 col-md-4">
                        <div class="widget">
                            <div class="text-center">
                                <!-- Contact Info Box Starts -->
                                <div class="contact-info-box">
                                    <div class="contact-info-box-content">
                                        <h3 class="title-about risk-title">Current Balance :</h3>
                                        <p>{{ $balance->balance }} - {{ $basic->currency }}</p>
                                    </div>
                                </div>
                                <!-- Contact Info Box Ends -->
                                <!-- Contact Info Box Starts -->
                                <div class="contact-info-box">
                                    <div class="contact-info-box-content">
                                        <h3 class="title-about risk-title">{{ $method->name }}</h3>
                                        <p>Limit - ( {!! $method->withdraw_min !!} to {{ $method->withdraw_max }} ) {{ $basic->currency }}</p>
                                        <p>
                                            Fix Charge - {{ $method->fix }} {{ $basic->currency }}
                                        </p>
                                        <p>
                                            Percentage - {{ $method->percent }} <i class="fa fa-percent"></i>
                                        </p>
                                        <p>
                                            Duration - {!! $method->duration !!} Days
                                        </p>

                                        <a href="{{ route('withdraw-request') }}" class="btn bold uppercase btn-primary btn-block btn-icon icon-left"><i class="fa fa-arrow-left"></i> Another Method</a>
                                    </div>
                                </div>
                                <!-- Contact Info Box Ends -->
                            </div>
                        </div>
                    </div>
                    <!-- Contact Widget Ends -->
                    <div class="col-xs-12 col-md-8 contact-form">
                            <!-- Input Field Starts -->
                            <div class="form-group col-md-6">
                                <label>Request Amount ({{ $basic->currency }}):</label>
                                <input type="text" value="{{ $withdraw->amount }}" readonly name="amount" id="amount" class="form-control" placeholder="Enter Deposit Amount" required>
                            </div>
                            <!-- Input Field Ends -->
                            <!-- Input Field Starts -->
                            <div class="form-group col-md-6">
                                <label> <label>Withdrawal Charge  ({{ $basic->currency }}):</label></label>
                                <input type="text" value="{{ round($withdraw->charge,$basic->deci )}}" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                            </div>
                            <!-- Input Field Ends -->
                            <!-- Input Field Starts -->
                            <div class="form-group col-md-6">
                                <label> <label>Total Amount ({{ $basic->currency }}):</label></label>
                               <input type="text" value="{{ $withdraw->net_amount }}" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                            </div>
                            <!-- Input Field Ends -->
                            <!-- Input Field Starts -->
                            <div class="form-group col-md-6">
                                <label> <label>Available Balance ({{ $basic->currency }}):</label></label>
                                 <input type="text" value="{{ $balance->balance - $withdraw->net_amount }}" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                            </div>
                            <!-- Input Field Ends -->
                            <div class="form-group col-xs-12">
                                <h3 class="title-about risk-title"> Payment Send Details</h3>
                            </div>


                            {!! Form::open(['route'=>'withdraw-submit']) !!}
                            <input type="hidden" name="withdraw_id" value="{{ $withdraw->id }}">
                            <!-- Input Field Starts -->
                            <div class="form-group col-xs-12">
                                <label>Sending Details</label>
                                 <textarea name="send_details" id="" rows="4" class="form-control bold input-lg" placeholder="Sending Details" required></textarea>
                            </div>
                            <!-- Input Field Ends -->
                          
                            <!-- Input Field Starts -->
                            <div class="form-group col-xs-12">
                                <label>Message ( If Any )</label>
                                <textarea name="message" id="" rows="3" class="form-control bold input-lg" placeholder="Message ( If Any )"></textarea>
                            </div>
                            <!-- Input Field Ends -->
                            <!-- Submit Form Button Starts -->
                            <div class="form-group col-xs-12 col-sm-4">
                               <button class="btn btn-primary btn-icon bold uppercase icon-left btn-block"><i class="fa fa-send"></i> Submit Withdraw</button>
                            </div>
                            {!! Form::close() !!}

                    </div>
                   
                </div>
            </div>
        </section>
        <!-- Contact Section Ends -->

@endsection
@section('script')

@endsection

