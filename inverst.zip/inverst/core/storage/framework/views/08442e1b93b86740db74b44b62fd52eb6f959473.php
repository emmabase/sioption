

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.breadcam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- Pricing Starts -->
        <section class="pricing">
            <div class="container">
                <!-- Section Content Starts -->
                <div class="row pricing-tables-content">
                    <div class="pricing-container">
                        
                        <!-- Pricing Tables Starts -->
                        <ul class="pricing-list bounce-invert">
                            <?php $__currentLoopData = $plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
                                <ul class="pricing-wrapper">
                                    <!-- Buy Pricing Table #1 Starts -->
                                    <li data-type="buy" class="is-visible">
                                        <header class="pricing-header">
                                            <h2><?php echo e($p->name); ?><span><?php echo e($p->compound->name); ?><br>For <?php echo e($p->time); ?> times </span></h2>
                                            <div class="price">
                                                <span class="value"><?php echo e($p->percent); ?>%</span>
                                            </div>
                                        </header>
                                        <footer class="pricing-footer">
                                            <span><?php echo e($basic->symbol); ?> <?php echo e($p->minimum); ?> - <?php echo e($basic->symbol); ?> <?php echo e($p->maximum); ?></span>
                                        </footer>
                                       <button type="submit" class="btn btn-primary bold uppercase btn-block btn-icon icon-left plan_id radious-zero" value="<?php echo e($p->id); ?>" data-toggle="modal" data-target="#invest_review_modal">
                                                 Invest
                                            </button>
                                            <form method="POST" action="<?php echo e(route('investment-post')); ?>" class="form-inline">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($p->id); ?>">
                                            
                                        </form>
                                    </li>
                                    <!-- Buy Pricing Table #1 Ends -->
                                </ul>
                            </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!-- Pricing Ends -->

<!-- Modal -->
  <div class="modal fade" id="invest_review_modal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">New Investment:</h4>
        </div>
        <div class="modal-body">
              <div class="row">
        <div class="col-md-4">
            <div class="col-sm-12 text-center">
                <div class="panel panel-default panel-pricing">
                    <div style="padding: 10px" class="panel-heading">
                        <h3 style="font-size: 28px;"><b style="color:#ffffff"><span id="name"></span></b></h3>
                    </div>
                    <div style="font-size: 18px;padding: 18px;" class="panel-body text-center">
                        <p><strong style="font-size: 20px;"> <span id="min_amount"></span> - <span id="max_amount"></span> <?php echo e($basic->currency); ?></strong></p>
                    </div>
                    <ul style="font-size: 15px;" class="list-group text-center bold">
                        <li class="list-group-item" style="padding: 18px 0px;">
                            <i class="fa fa-check"></i> Commission - <span id="percentage"></span> <i class="fa fa-percent"></i> 
                        </li>
                        <li class="list-group-item" style="padding: 18px 0px;">
                            <i class="fa fa-check"></i> Repeat - <span id="time"></span> Times 
                        </li>
                        <li class="list-group-item" style="padding: 18px 0px;">
                            <i class="fa fa-check"></i> Compound - <span class="aaaa"><span id="compound_name"></span></span>
                        </li>
                    </ul>
                    <div class="panel-footer" style="overflow: hidden">
                        <div class="col-sm-12">
                            <button class="btn btn-primary bold uppercase btn-block btn-icon icon-left radious-zero"  data-dismiss="modal">
                                <i class="fa fa-arrow-left"></i> Change Package
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                <!-- panel head -->
                <div class="panel-heading">
                    <div class="panel-title bold uppercase"><i class="fa fa-eye"></i> <strong>Investment Review</strong></div>
                </div>
                <!-- panel body -->
                <div class="panel-body">
                    <div class="row">
                           <div class="col-md-6" style="padding-right:0px;">
                                  <div class="text-left">
                                    <h5 class="bold uppercase">Current Balance: <strong><?php echo e(round(Auth::user()->balance, $basic->deci)); ?> - <?php echo e($basic->currency); ?></strong></h5>
                                </div>
                            </div>
                            
                            <div class="col-md-6" style="padding-right:0px;">
                                <div class="text-left">
                                  <h5 class="bold uppercase" >Remain Balance: <strong> <span id="remain_balance"><?php echo e(round(Auth::user()->balance, $basic->deci)); ?></span> - <?php echo e($basic->currency); ?></strong></h5>
                                </div>       
                            </div>      
                    </div>
                        <ul style='font-size: 15px;' class="list-group bold">
                             
                             <li class="list-group-item">
                                <div class="row">
                                <div class="col-md-5 text-right">
                                   Investment Amount :
                                </div>    
                                <div class="col-md-7 text-left">
                                     <div class="input-group">
                                        <input type="text" value="" name="amount" id="amount" class="form-control bold" placeholder="Invest Amount" required>
                                        <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                       
                                    </div>
                                </div>    
                                </div>
                             </li>

                             <li class="list-group-item">
                                <div class="row">
                                <div class="col-md-5 text-right">
                                  Per Time: 
                                </div>    
                                <div class="col-md-7 text-left">
                                   <div class="input-group">
                                        <input type="text" value="" name="amount" id="comission_amount" class="form-control bold" placeholder="Per Time" readonly>
                                        <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                        
                                    </div>
                                </div>    
                                </div>
                             </li>

                              <li class="list-group-item">
                                <div class="row">
                                <div class="col-md-5 text-right">
                                    Total Return: 
                                </div>    
                                <div class="col-md-7 text-left">
                                   <div class="input-group">
                                        <input type="text" value="" name="amount" id="total_return" class="form-control bold" placeholder="Total Return" readonly>
                                        <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                       
                                    </div>
                                </div>    
                                </div>
                             </li>

                             <li class="list-group-item">
                                <div class="row">
                                <div class="col-md-5 text-right">
                                   Total Interest: 
                                </div>    
                                <div class="col-md-7 text-left">
                                    <div class="input-group">
                                        <input type="text" value="" name="amount" id="total_interest" class="form-control bold" placeholder="Total Interest" readonly>
                                        <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                    </div>
                                </div>    
                                </div>
                             </li>
                        </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
                <div class="form-group">
                  <form method="post" action="<?php echo e(route('investment-submit')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="amount" id ="c_amount" value="0">
                        <input type="hidden" name="plan_id" id="plan_id" value="">
                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                        <div id="result"></div>
                    </form>
                        
                </div>
            </div>
        </div>
            
        <div class="modal-footer">
          <button type="button" class="btn btn-info btn-block" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
        $(document).ready(function () {

            /*Modal load activities*/
            $(document).on("click", '.plan_id', function (e) {
                var id = $(this).val();

                $("#amount").val('');
                $("#comission_amount").val('');
                $("#total_return").val('');
                $("#total_interest").val('');

                 $.post(
                        '<?php echo e(route('invest-amount-review')); ?>',
                        {
                            _token: '<?php echo e(csrf_token()); ?>',
                            id : id,
                        },
                        function(data) {
                            console.log(data);
                            $("#plan_id").val(data.id);
                            $("#name").text(data.name);
                            $("#min_amount").text(data.minimum);
                            $("#max_amount").text(data.maximum);
                            $("#percentage").text(data.percent);
                            $("#compound_name").text(data.compound_name);
                            $("#time").text(data.time);

                            $("#result").html(data);
                        }
                );

            });

             /*Modal data review activities*/
            $('#amount').on('keypress, keyup', function() {
                
                var amount          = parseInt($("#amount").val());
                var plan            = $("#plan_id").val();
                var balance         = "<?php echo e(round(Auth::user()->balance, $basic->deci)); ?>";
                var comissionRate   = parseInt($("#percentage").text())/100;   
                var comissionTime   = parseInt($("#time").text());
                var comissionAmount = amount * comissionRate;
                var totalReturn     = comissionAmount * comissionTime;
                var totalInterest   = totalReturn - amount;

                var remainBalance = parseInt(balance)-parseInt(amount);
                if(amount == ''|| amount <=0){

                    $("#remain_balance").text(balance);
                        
                        InputBoxZero();

                }else if(amount<=balance){
                     
                      $("#remain_balance").text(remainBalance);
                     
                      $("#comission_amount").val(comissionAmount);
                      $("#total_return").val(totalReturn);
                      $("#total_interest").val(totalInterest);

                }else if(amount>balance){
                        swal("Ops!", "Input amount not available in your balance!", "error")
                        $("#amount").val('');
                        InputBoxZero();
                        $("#remain_balance").text(balance);
                }else{
                    $("#remain_balance").text(balance);
                    InputBoxZero();
                }

                if(amount>balance){
                    $("#c_amount").val(0); 
                }else{
                    $("#c_amount").val(amount); 
                }

                $.post(
                        '<?php echo e(url('/user/invest-amount-chk')); ?>',
                        {
                            _token: '<?php echo e(csrf_token()); ?>',
                            amount : amount,
                            plan : plan
                        },
                        function(data) {

                            $("#result").html(data);
                        }
                );
            });

            function InputBoxZero(){
                $("#comission_amount").val('');
                $("#total_return").val('');
                $("#total_interest").val('');
            }
        });
</script>

    <?php if(session('success')): ?>
        <script type="text/javascript">
            $(document).ready(function(){

                swal("Success!", "<?php echo e(session('success')); ?>", "success");

            });
        </script>

    <?php endif; ?>



    <?php if(session('alert')): ?>

        <script type="text/javascript">
            $(document).ready(function(){
                swal("Sorry!", "<?php echo e(session('alert')); ?>", "error");
            });

        </script>

    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>