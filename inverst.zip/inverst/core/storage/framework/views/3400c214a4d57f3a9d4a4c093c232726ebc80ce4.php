<!DOCTYPE html>
<html dir="ltr" lang="en">

<!-- Mirrored from html.kodesolution.live/s/cryptopress/v3.0/demo/index-dark-mp-layout1.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 23 Sep 2020 13:16:24 GMT -->
<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>

<!-- Page Title -->
<title><?php echo e($site_title); ?> | <?php echo e($page_title); ?></title>

<!-- Favicon and Touch Icons -->
<link href="<?php echo e(asset('assets/newfront/images/favicon.png')); ?>" rel="shortcut icon" type="image/png">
<link href="<?php echo e(asset('assets/newfront/images/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
<link href="<?php echo e(asset('assets/newfront/images/apple-touch-icon-72x72.png')); ?>" rel="apple-touch-icon" sizes="72x72">
<link href="<?php echo e(asset('assets/newfront/images/apple-touch-icon-114x114.png')); ?>" rel="apple-touch-icon" sizes="114x114">
<link href="<?php echo e(asset('assets/newfront/images/apple-touch-icon-144x144.png')); ?>" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="<?php echo e(asset('assets/newfront/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/newfront/css/jquery-ui.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/newfront/css/animate.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/newfront/css/css-plugin-collections.css')); ?>" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link href="<?php echo e(asset('assets/newfront/css/menuzord-megamenu.css')); ?>" rel="stylesheet"/>
<link id="<?php echo e(asset('assets/newfront/menuzord-menu-skins')); ?>" href="css/menuzord-skins/menuzord-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="<?php echo e(asset('assets/newfront/css/style-main.css')); ?>" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="<?php echo e(asset('assets/newfront/css/preloader.css')); ?>" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="<?php echo e(asset('assets/newfront/css/custom-bootstrap-margin-padding.css')); ?>" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="<?php echo e(asset('assets/newfront/css/responsive.css')); ?>" rel="stylesheet" type="text/css">
<!-- CSS | For Dark Layout -->
<link href="<?php echo e(asset('assets/newfront/css/style-main-dark.css')); ?>" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="<?php echo e(asset('assets/newfront/js/revolution-slider/css/settings.css')); ?>" rel="stylesheet" type="text/css"/>
<link  href="<?php echo e(asset('assets/newfront/js/revolution-slider/css/layers.css')); ?>" rel="stylesheet" type="text/css"/>
<link  href="<?php echo e(asset('assets/newfront/js/revolution-slider/css/navigation.css')); ?>" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="<?php echo e(asset('assets/newfront/css/colors/theme-skin-color-set2.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/front/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/front/newcss/select2.min.css')); ?>" rel="stylesheet">

<!-- Start of Async Drift Code -->
<script>
"use strict";

!function() {
  var t = window.driftt = window.drift = window.driftt || [];
  if (!t.init) {
    if (t.invoked) return void (window.console && console.error && console.error("Drift snippet included twice."));
    t.invoked = !0, t.methods = [ "identify", "config", "track", "reset", "debug", "show", "ping", "page", "hide", "off", "on" ], 
    t.factory = function(e) {
      return function() {
        var n = Array.prototype.slice.call(arguments);
        return n.unshift(e), t.push(n), t;
      };
    }, t.methods.forEach(function(e) {
      t[e] = t.factory(e);
    }), t.load = function(t) {
      var e = 3e5, n = Math.ceil(new Date() / e) * e, o = document.createElement("script");
      o.type = "text/javascript", o.async = !0, o.crossorigin = "anonymous", o.src = "https://js.driftt.com/include/" + n + "/" + t + ".js";
      var i = document.getElementsByTagName("script")[0];
      i.parentNode.insertBefore(o, i);
    };
  }
}();
drift.SNIPPET_VERSION = '0.3.1';
drift.load('wxacn2y8it3i');
</script>

<!-- external javascripts -->
<script src="<?php echo e(asset('assets/newfront/js/jquery-2.2.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/newfront/js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/newfront/js/bootstrap.min.js')); ?>"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="<?php echo e(asset('assets/newfront/js/jquery-plugin-collection.js')); ?>"></script>

   <!-- Template JS Files -->
   <script src="<?php echo e(asset('assets/front/newjs/modernizr.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admin/css/sweetalert2.all.min.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>



<?php echo $__env->yieldContent('style'); ?>
    <!-- end -->

    <style type="text/css">
        .swal2-container {
          z-index: 9999999 !important;
        }
        .swal2-popup {
          font-size: 0.8rem !important;
          
        }
        .modal{
          z-index: 9999999 !important;
        }
        th{
          width: 20% !important;
        }
        .pagination>.active>a, .pagination>.active>a:focus, .pagination>.active>a:hover, .pagination>.active>span, .pagination>.active>span:focus, .pagination>.active>span:hover {
             
              background-color: #fd961a !important;
              border-color: #fd961a !important;
              
          }
           .pagination>.disabled>a, .pagination>.disabled>a:focus, .pagination>.disabled>a:hover, .pagination>.disabled>span, .pagination>.disabled>span:focus, .pagination>.disabled>span:hover{
             
              background-color: #fd961a !important;
               background: #222 !important;
               border: 1px solid #333;
              
          }
        .call-action-all {
          padding: 0;
          position: relative;
          background:  url('<?php echo e(asset('assets/images/backgrounds/call-to-action-bg.jpg')); ?>');
          background-size: cover;
          background-position: center center;
        }
        .banner-area {
          position: relative;
          padding: 0;
          color: #fff;
          background-image: url('<?php echo e(asset('assets/images/backgrounds/bg-banner.jpg')); ?>');
          background-size: cover;
          background-position: center center;
          background-repeat: no-repeat;
        }
        @media  screen and (max-width: 767px) {
          .table-responsive{
            border: 0px !important;
          }
        }
    </style>

   


</head>

<body class="dark">
<div id="wrapper" class="clearfix">
  <!-- preloader -->
  <div id="preloader">
    <div id="spinner">
      <div class="preloader-dot-loading">
        <div class="cssload-loading"><i></i><i></i><i></i><i></i></div>
      </div>
    </div>
    <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
  </div> 
<!-- End Preload -->
<header id="header" class="header modern-header modern-header-theme-colored">
    <div class="header-top bg-theme-colored sm-text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <div class="widget text-white">
              <i class="fa fa-clock-o text-theme-colored2"></i> Opening Hours:  Mon - Tues : 6.00 am - 10.00 pm, Sunday Closed
            </div>
          </div>
      
        </div>
      </div>
    </div>
    <div class="header-middle p-0 bg-lightest xs-text-center pb-30">
      <div class="container pt-20 pb-20">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-3">
            <a class="menuzord-brand pull-left flip sm-pull-center mb-15" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/newfront/images/logo-wide-white.png')); ?>" alt=""></a>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-9">
            <div class="header-widget-contact-info-box sm-text-center">
              <div class="media element contact-info">
                <div class="media-left">
                  <a href="#">
                    <i class="fa fa-envelope text-theme-colored2 font-icon sm-display-block"></i>
                  </a>
                </div>
                <div class="media-body">
                  <a href="#" class="title">Mail Us Today</a>
                  <h5 class="media-heading subtitle"><?php echo e($basic->email); ?></h5>
                </div>
              </div>
              <div class="media element contact-info">
                <div class="media-left">
                  <a href="#">
                    <i class="fa fa-phone-square text-theme-colored2 font-icon sm-display-block"></i>
                  </a>
                </div>
                <div class="media-body">
                  <a href="#" class="title">Call us for more details</a>
                  <h5 class="media-heading subtitle"><?php echo e($basic->phone); ?></h5>
                </div>
              </div>
              <div class="media element contact-info">
                <div class="media-left">
                  <a href="#">
                    <i class="fa fa-building-o text-theme-colored2 font-icon sm-display-block"></i>
                  </a>
                </div>
                <div class="media-body">
                  <a href="#" class="title">Company Location</a>
                  <h5 class="media-heading subtitle"><?php echo e($basic->address); ?></h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed">
        <div class="container">
          <nav id="menuzord" class="menuzord yellow">
            <ul class="menuzord-menu">
              <li class="home"><a href="<?php echo e(route('home')); ?>"><i class="fa fa-home font-28"></i></a></li>
              </li>
              <li><a href="<?php echo route('user-dashboard'); ?>">Dashboard</a>
              </li>
              <li><a href="javascript:void(0)">Investment </a>
                <ul class="dropdown">
                    <li><a href="<?php echo route('investment-new'); ?>">New Investment</a></li>
                    <li><a href="<?php echo route('investment-history'); ?>">Investment History</a></li>
                    <li><a href="<?php echo route('user-repeat-history'); ?>">Repeat History</a></li>
                </ul>
              </li>
              <li><a href="javascript:void(0)">transaction </a>
                <ul class="dropdown">
                    <li><a href="<?php echo route('deposit-fund'); ?>">Deposit Fund</a></li>
                    <li><a href="<?php echo route('withdraw-request'); ?>">Withdraw Fund</a></li>
                </ul>
              </li>
              <li><a href="javascript:void(0)">Hi. <?php echo e(Auth::user()->name); ?></a>
                <ul class="dropdown">
                <li>
                    <a href="<?php echo route('edit-profile'); ?>">Edit Profile
                    </a>
                </li>
                <li>
                    <a href="<?php echo route('change-password'); ?>">Change Password
                    </a>
                </li>
                <li>
                    <a href="<?php echo route('support-all'); ?>"><span class="title">Get Support</span></a>
                </li>     
                <li> 
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="">Log Out
                    </a>
                </li>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>
                            
                </ul>
              </li>
            </ul>
          
          </nav>
        </div>
      </div>
    </div>
  </header>
    <?php echo $__env->yieldContent('content'); ?>
 
 <!-- Footer -->
 <footer id="footer" class="footer" data-bg-img="images/footer-bg.png" data-bg-color="#152029">
    <div class="container pt-70 pb-40">
      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <img class="mt-5 mb-20" alt="" src="images/logo-white-footer.png">
            <p><?php echo e($basic->address); ?>.</p>
            <ul class="list-inline mt-5">
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-phone text-theme-colored2 mr-5"></i> <a class="text-gray" href="#"><?php echo e($basic->phone); ?></a> </li>
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-theme-colored2 mr-5"></i> <a class="text-gray" href="#"><?php echo e($basic->email); ?></a> </li>
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-globe text-theme-colored2 mr-5"></i> <a class="text-gray" href="#">www.yourdomain.com</a> </li>
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h4 class="widget-title">Useful Links</h4>
            <ul class="list angle-double-right list-border">
              <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
              <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
              <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Opening Hours</h4>
            <div class="opening-hours">
              <ul class="list-border">
                <li class="clearfix"> <span> Mon - Tues :  </span>
                  <div class="value pull-right"> 6.00 am - 10.00 pm </div>
                </li>
                <li class="clearfix"> <span> Wednes - Thurs :</span>
                  <div class="value pull-right"> 8.00 am - 6.00 pm </div>
                </li>
                <li class="clearfix"> <span> Fri : </span>
                  <div class="value pull-right"> 3.00 pm - 8.00 pm </div>
                </li>
                <li class="clearfix"> <span> Sun : </span>
                  <div class="value pull-right"> Closed </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="widget dark">
            <h5 class="widget-title mb-10">Connect With Us</h5>
            <ul class="styled-icons icon-bordered icon-sm">
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-skype"></i></a></li>
              <li><a href="#"><i class="fa fa-youtube"></i></a></li>
              <li><a href="#"><i class="fa fa-instagram"></i></a></li>
              <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom bg-theme-colored-transparent-5">
      <div class="container pt-20 pb-20">
        <div class="row">
          <div class="col-md-6">
            <p class="font-11 text-black-777 m-0"><?php echo $basic->copy_text; ?></p>
          </div>
        
        </div>
      </div>
    </div>
  </footer>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- JS | Custom script for all pages -->
<script src="<?php echo e(asset('assets/newfront/js/custom.js')); ?>"></script>


 <!-- Template JS Files -->
    <script src="<?php echo e(asset('assets/front/newjs/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/newjs/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/newjs/custom.js')); ?>"></script>


    
    <style type="text/css">
    li.export-main {
        visibility: hidden;
    }
</style>


<script src="<?php echo e(asset('assets/front/js/jquery.dataTables.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/front/js/dataTables.bootstrap.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('script'); ?>
<!--Main js file load-->
<script src="<?php echo e(asset('assets/front/js/main.js')); ?>"></script>

<script src="<?php echo e(asset('assets/front/2/js/main.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script> -->

<!--swal alert message-->
<?php if(session('success')): ?>
   <script type="text/javascript">
       $(document).ready(function(){
           swal("Success!", "<?php echo e(session('success')); ?>", "success");
       });
   </script>
<?php endif; ?>
<?php if(session('alert')): ?>
   <script type="text/javascript">
       $(document).ready(function(){
           swal("Sorry!", "<?php echo e(session('alert')); ?>", "error");
       });
   </script>
<?php endif; ?>
<?php if(session('error')): ?>
   <script type="text/javascript">
       $(document).ready(function(){
           swal("Sorry!", "<?php echo e(session('error')); ?>", "error");
       });
   </script>
<?php endif; ?>

<?php if(session('message')): ?>
   <script type="text/javascript">
       $(document).ready(function(){
           swal("<?php echo e(session('message')); ?>");
       });
   </script>
<?php endif; ?>
<script>
       $(document).ready(function() {
           $('#sample_1').DataTable()
       });
   </script>
<!--end swal alert message-->


<script>
var mobile = (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent));

hljs.initHighlightingOnLoad();
hljs.configure({useBR: true});
jQuery('#raindrops').raindrops({color:'#fff',canvasHeight:5});
jQuery('#raindrops-green').raindrops({color:'#<?php echo e($basic->color); ?> ',canvasHeight:5});

</script>
</body>
</html>






