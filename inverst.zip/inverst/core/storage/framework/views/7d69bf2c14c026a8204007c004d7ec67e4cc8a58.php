

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.breadcam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    

 <section class="services">
            <div class="container">
                <div class="row">
                    <!-- Service Box Starts -->
                    <div class="col-md-3 service-box">
                        <div>
                            <img id="buy-sell-bitcoins" src="<?php echo e(asset('assets/images/icons/orange/download-bitcoin.png')); ?>" alt="buy and sell bitcoins">
                            <div class="service-box-content">
                                <h3><?php echo e($basic->symbol); ?> <?php echo e(round($balance->balance, $basic->deci)); ?></h3>
                                <p>Current Balance</p>
                            </div>
                        </div>
                    </div>
                    <!-- Service Box Ends -->
                    <!-- Service Box Starts -->
                    <div class="col-md-3 service-box">
                        <div>
                           <img id="buy-sell-bitcoins" src="<?php echo e(asset('assets/images/icons/orange/world-coverage.png')); ?>" alt="buy and sell bitcoins">
                            <div class="service-box-content">
                                <h3><?php echo e($basic->symbol); ?> <?php echo e($repeat); ?></h3>
                                <p>Total Repeat</p>
                            </div>
                        </div>
                    </div>
                    <!-- Service Box Ends -->
                    <!-- Service Box Starts -->
                    <div class="col-md-3 service-box">
                        <div>
                            <img id="buy-sell-bitcoins" src="<?php echo e(asset('assets/images/icons/orange/payment-options.png')); ?>" alt="buy and sell bitcoins">
                            <div class="service-box-content">
                                <h3><?php echo e($basic->symbol); ?> <?php echo e($deposit); ?></h3>
                                <p>Total Deposits</p>
                            </div>
                        </div>
                    </div>
                    <!-- Service Box Ends -->
                    <!-- Service Box Starts -->
                    <div class="col-md-3 service-box">
                        <div>
                            <img id="buy-sell-bitcoins" src="<?php echo e(asset('assets/images/icons/orange/add-bitcoins.png')); ?>" alt="buy and sell bitcoins">
                            <div class="service-box-content">
                                <h3><?php echo e($basic->symbol); ?> <?php echo e($withdraw); ?></h3>
                                <p>Total Withdraws</p>
                            </div>
                        </div>
                    </div>
                    <!-- Service Box Ends --> 
                    
                </div>
            </div>

            <div class="container">
    <div class="row">
         <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div id="tradingview_19631"></div>
  <div class="tradingview-widget-copyright"></div>
  <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
  <script type="text/javascript">
  new TradingView.widget(
  {
  "width": 1100,
  "height": 468,
  "symbol": "COINBASE:BTCUSD",
  "interval": "D",
  "timezone": "Etc/UTC",
  "theme": "Dark",
  "style": "0",
  "locale": "en",
  "toolbar_bg": "#f1f3f6",
  "enable_publishing": false,
  "allow_symbol_change": true,
  "hotlist": true,
  "container_id": "tradingview_19631"
}
  );
  </script>
</div>
<!-- TradingView Widget END -->

            <div class="container">
                <div class="row">
                     <div class="col-xs-12">
                        <h3 class="title-about risk-title"><?php echo $reference_title; ?></h3>
                    </div>
                </div>
                
            </div>
            
              <!--Start section-->
            <div class="container">
                <div class="row">
                    <!-- Purchased Products Starts -->
                    <div class="col-xs-12 table-responsive">
                        <table class="table order " id="sample_1" style="width:100%">
                            <thead>
                                <tr>
                                    <th>ID#</th>
                                    <th class="th-lg">Register Date</th>
                                    <th>Username</th>
                                    <th>User Email</th>
                                    <th>User Phone</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                 <?php $i=0;?>
                        <?php $__currentLoopData = $reference_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++;?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e(date('d-F-Y h:i A',strtotime($p->created_at))); ?></td>
                                <td><?php echo e($p->username); ?></td>
                                <td><?php echo e($p->email); ?></td>
                                <td><?php echo e($p->phone); ?></td>
                                <td>
                                    <?php if($p->status == 1): ?>
                                        <span class="label bold label-danger bold uppercase"><i class="fa fa-user-times"></i> Blocked</span>
                                    <?php else: ?>
                                        <span class="label bold label-success bold uppercase"><i class="fa fa-check"></i> Active</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- Purchased Products Ends -->
                   
                </div>
            </div>

            <br>


            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                       
                            <label><strong>YOUR REFERRAL LINK:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>Number OF YOUR REFERRALS USER : <?php echo e($refer); ?> </strong></label>
                            <div class="input-group mb15">
                                <input type="text" class="form-control input-lg" id="ref" value="<?php echo e(route('auth.reference-register',Auth::user()->username)); ?>"/>
                                <span class="input-group-btn">
                                    <button data-copytarget="#ref" class="btn btn-success btn-lg">COPY</button>
                                </span>
                            </div>
                     
                    </div>
                </div>
            </div>
            




        </section>
        <!-- Section Services Ends -->


       


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $('.has').tooltip({
            trigger: 'click',
            placement: 'bottom'
        });

        function setTooltip(btn, message) {
            $(btn).tooltip('hide')
                    .attr('data-original-title', message)
                    .tooltip('show');
        }


        function hideTooltip(btn) {
            setTimeout(function() {
                $(btn).tooltip('hide');
            }, 1000);
        }

        // Clipboard


        $(document).ready(function () {

            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);

            });

        });
        $('#btnYes').click(function() {
            $('#formSubmit').submit();
        });
    </script>
    <script src="<?php echo e(asset('assets/admin/js/clipboard.min.js')); ?>"></script>
    <script>
        /*new Clipboard('.has');*/

    </script>
    <script>
        (function() {

            'use strict';

            // click events
            document.body.addEventListener('click', copy, true);

            // event handler
            function copy(e) {

                // find target element
                var
                        t = e.target,
                        c = t.dataset.copytarget,
                        inp = (c ? document.querySelector(c) : null);

                // is element selectable?
                if (inp && inp.select) {

                    // select text
                    inp.select();

                    try {
                        // copy text
                        document.execCommand('copy');
                        inp.blur();

                        // copied animation
                        t.classList.add('copied');
                        setTimeout(function() { t.classList.remove('copied'); }, 1500);
                    }
                    catch (err) {
                        alert('please press Ctrl/Cmd+C to copy');
                    }

                }

            }

        })();

    </script>

    <script src="<?php echo e(asset('assets/admin/js/jquery.waypoints.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-tooltip.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/admin/js/jquery.counterup.min.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>