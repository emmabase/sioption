<?php $__env->startSection('content'); ?>
    
<?php echo $__env->make('layouts.breadcam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


 <!-- Start main-content -->
 <div class="main-content">

<section class="bg-lighter">
<div class="container">
 
  <div class="section-content">
    <div class="row">
    <?php $__currentLoopData = $method; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-xs-6 col-sm-6 col-md-3">
        <div class="post icon-box p-30 bg-white bg-hover-theme-colored border-1px text-center">
          <div class="media-body">
          <h5><?php echo e($p->name); ?><span><br><br>Charge - <?php echo e($p->fix); ?> + <?php echo e($p->percent); ?> <i class="fa fa-percent"></i> <?php echo e($basic->currency); ?><br><br>Processing Time - <?php echo $p->duration; ?> Days</span></h5>
            <a href="javascript:;" class="btn btn-primary btn-block" <?php if($basic->withdraw_status == 0): ?> disabled <?php else: ?> onclick="jQuery('#modal-<?php echo e($p->id); ?>').modal('show');" <?php endif; ?> class="btn btn-info btn-block btn-icon btn-lg bold icon-left"> Withdraw Now</a>
          </div>                
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
</section>



        
    <?php $__currentLoopData = $method; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="modal fade" id="modal-<?php echo e($b->id); ?>">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title"></i> <strong>Withdraw via <?php echo e($b->name); ?></strong> </h4>
                    </div>
                    <?php echo e(Form::open()); ?>

                    <input type="hidden" name="method_id" value="<?php echo e($b->id); ?>">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <span style="margin-bottom: 10px;"><code>Withdraw Charge : (<?php echo e($b->fix); ?> + <?php echo e($b->percent); ?>%) - <?php echo e($basic->currency); ?></code></span>
                                        <div class="input-group" style="margin-top: 10px;margin-bottom: 10px;">
                                            <input type="number" value="" id="amount" name="amount" class="form-control" required placeholder="Withdraw Amount" />
                                            <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <br>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <button class="btn btn-primary btn-block"></i> Withdraw Now</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>