

 <!-- Banner Area Starts -->
  <section class="inner-header divider layer-overlay overlay-dark-6" data-bg-img="<?php echo e(asset('assets/newfront/images/bg/bg17.jpg')); ?>">
    <div class="container pt-120 pb-60">
      <!-- Section Content -->
      <div class="section-content">
        <div class="row"> 
          <div class="col-md-6">
            <h2 class="text-theme-colored2 font-36"><?php echo $page_title; ?></h2>
            <ol class="breadcrumb text-left mt-10 white">
              <li><a href="<?php echo e(route('faqs')); ?>">Home</a></li>
              <li><a href="<?php echo e(route('faqs')); ?>"><?php echo $page_title; ?></a></li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  </section>
        <!-- Banner Area Ends -->

         <script src="https://widgets.coingecko.com/coingecko-coin-price-marquee-widget.js"></script>
<coingecko-coin-price-marquee-widget currency="usd" coin-ids="bitcoin,ethereum,eos,ripple,litecoin" locale="en"></coingecko-coin-price-marquee-widget>