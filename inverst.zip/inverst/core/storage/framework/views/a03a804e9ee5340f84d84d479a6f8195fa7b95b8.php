

 <!-- Banner Area Starts -->
        <section class="banner-area">
      <div class="banner-overlay">
        <div class="banner-text text-center">
          <div class="container">
            <!-- Section Title Starts -->
            <div class="row text-center">
              <div class="col-xs-12">
                <!-- Title Starts -->
                <h3 class="title-head"><?php echo $page_title; ?></h3>
                <!-- Title Ends -->
                <hr>
                <!-- Breadcrumb Starts -->
                <ul class="breadcrumb">
                  <li><a href="<?php echo e(url('/')); ?>"> home</a></li>
                  <li><?php echo $page_title; ?></li>
                </ul>
                <!-- Breadcrumb Ends -->
              </div>
            </div>
            <!-- Section Title Ends -->
          </div>
        </div>
      </div>
        </section>
        <!-- Banner Area Ends -->

         <script src="https://widgets.coingecko.com/coingecko-coin-price-marquee-widget.js"></script>
<coingecko-coin-price-marquee-widget currency="usd" coin-ids="bitcoin,ethereum,eos,ripple,litecoin" locale="en"></coingecko-coin-price-marquee-widget>