<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> | <?php echo e($page_title); ?></title>
    <!--Favicon add-->
    <link rel="shortcut icon" type="image/png" src="<?php echo e(asset('assets/images/logo/icon.png')); ?>">


    <!-- Template CSS Files -->

    <link href="<?php echo e(asset('assets/front/newcss/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/front/newcss/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/front/newcss/magnific-popup.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/front/newcss/select2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/front/newcss/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/front/newcss/skins/orange.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('assets/admin/css/sweetalert.css')); ?>" rel="stylesheet">

     <!-- Template JS Files -->
     <script src="<?php echo e(asset('assets/front/newjs/modernizr.js')); ?>"></script>

    <?php echo $__env->yieldContent('style'); ?>
    <!-- end -->

    <style type="text/css">
        .call-action-all {
          padding: 0;
          position: relative;
          background:  url('<?php echo e(asset('assets/images/backgrounds/call-to-action-bg.jpg')); ?>');
          background-size: cover;
          background-position: center center;
        }
        .banner-area {
          position: relative;
          padding: 0;
          color: #fff;
          background-image: url('<?php echo e(asset('assets/images/backgrounds/bg-banner.jpg')); ?>');
          background-size: cover;
          background-position: center center;
          background-repeat: no-repeat;
        }
    </style>


    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
    var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
    s1.async=true;
    s1.src='https://embed.tawk.to/5c3ebefdab5284048d0d28d4/default';
    s1.charset='UTF-8';
    s1.setAttribute('crossorigin','*');
    s0.parentNode.insertBefore(s1,s0);
    })();
    </script>
<!--End of Tawk.to Script-->
   


</head>

<body>
 <!-- SVG Preloader Starts -->
    <div id="preloader">
        <div id="preloader-content">
            <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="150px" height="150px" viewBox="100 100 400 400" xml:space="preserve">
                <filter id="dropshadow" height="130%">
                <feGaussianBlur in="SourceAlpha" stdDeviation="5"/>
                <feOffset dx="0" dy="0" result="offsetblur"/>
                <feFlood flood-color="red"/>
                <feComposite in2="offsetblur" operator="in"/>
                <feMerge>
                <feMergeNode/>
                <feMergeNode in="SourceGraphic"/>
                </feMerge>
                </filter>          
                <path class="path" fill="#000000" d="M446.089,261.45c6.135-41.001-25.084-63.033-67.769-77.735l13.844-55.532l-33.801-8.424l-13.48,54.068
                    c-8.896-2.217-18.015-4.304-27.091-6.371l13.568-54.429l-33.776-8.424l-13.861,55.521c-7.354-1.676-14.575-3.328-21.587-5.073
                    l0.034-0.171l-46.617-11.64l-8.993,36.102c0,0,25.08,5.746,24.549,6.105c13.689,3.42,16.159,12.478,15.75,19.658L208.93,357.23
                    c-1.675,4.158-5.925,10.401-15.494,8.031c0.338,0.485-24.579-6.134-24.579-6.134l-9.631,40.468l36.843,9.188
                    c8.178,2.051,16.209,4.19,24.098,6.217l-13.978,56.17l33.764,8.424l13.852-55.571c9.235,2.499,18.186,4.813,26.948,6.995
                    l-13.802,55.309l33.801,8.424l13.994-56.061c57.648,10.902,100.998,6.502,119.237-45.627c14.705-41.979-0.731-66.193-31.06-81.984
                    C425.008,305.984,441.655,291.455,446.089,261.45z M368.859,369.754c-10.455,41.983-81.128,19.285-104.052,13.589l18.562-74.404
                    C306.28,314.65,379.774,325.975,368.859,369.754z M379.302,260.846c-9.527,38.187-68.358,18.781-87.442,14.023l16.828-67.489
                    C327.767,212.14,389.234,221.02,379.302,260.846z"/>       
            </svg>
        </div>
    </div>
    <!-- SVG Preloader Ends -->


<!--
<div class="animation-element">
End Pre-Loader 
support bar  top start
<div class="support-bar-top wow slideInLeft" data-wow-duration="2s" id="raindrops-green">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="contact-info">
                    <a href="mailto:<?php echo e($basic->email); ?>"> <i class="fa fa-envelope email" aria-hidden="true"></i> <?php echo e($basic->email); ?></a>
                    <a href="#"> <i class="fa fa-phone" aria-hidden="true"></i> <?php echo e($basic->phone); ?> </a>
                </div>
            </div>
            <div class="col-md-6 text-right bounceIn">
                <div class="contact-admin">
                    <a href="<?php echo e(url('login')); ?>"><i class="fa fa-user"></i> LOGIN </a>
                    <a href="<?php echo e(url('register')); ?>"><i class="fa fa-user-plus"></i> REGISTER</a>
                    <div class="support-bar-social-links">
                        <?php $__currentLoopData = $social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($s->link); ?>"><?php echo $s->code; ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
-->

<!--support bar  top end-->
<!--main menu section start-->
<!-- Wrapper Starts -->
    <div class="wrapper">
        <!-- Header Starts -->
        <header class="header">
            <div class="container">
                <div class="row">
                    <!-- Logo Starts -->
                    <div class="main-logo col-xs-12 col-md-3 col-md-2 col-lg-2 hidden-xs">
                        <a href="<?php echo e(url('/')); ?>">
                            <img id="logo" class="img-responsive" src="<?php echo e(asset('assets/images/logo/logo-dark.png')); ?>" alt="logo">
                        </a>
                    </div>
                    <!-- Logo Ends -->
                    <!-- Statistics Starts -->
                    <div class="col-md-7 col-lg-7">
                        <ul class="unstyled bitcoin-stats text-center">
                            <li>
                                <h6>9,450 USD</h6><span>Last trade price</span></li>
                            <li>
                                <h6>+5.26%</h6><span>24 hour price</span></li>
                            <li>
                                <h6>12.820 BTC</h6><span>24 hour volume</span></li>
                            <li>
                                <h6>2,231,775</h6><span>active traders</span></li>
                            <li>
                                <div class="btcwdgt-price" data-bw-theme="light" data-bw-cur="usd"></div>
                                <span>Live Bitcoin price</span>
                            </li>
                        </ul>
                    </div>
                    <!-- Statistics Ends -->
                    <!-- User Sign In/Sign Up Starts -->
                    <div class="col-md-3 col-lg-3">
                        <ul class="unstyled user">
                            <li class="sign-in"><a href="<?php echo e(url('login')); ?>" class="btn btn-primary"><i class="fa fa-user"></i> sign in</a></li>
                            <li class="sign-up"><a href="<?php echo e(url('register')); ?>" class="btn btn-primary"><i class="fa fa-user-plus"></i> register</a></li>
                        </ul>
                    </div>
                    <!-- User Sign In/Sign Up Ends -->
                </div>
            </div>
            <!-- Navigation Menu Starts -->
            <nav class="site-navigation navigation" id="site-navigation">
                <div class="container">
                    <div class="site-nav-inner">
                        <!-- Logo For ONLY Mobile display Starts -->
                        <a class="logo-mobile" href="<?php echo e(url('/')); ?>">
                            <img id="logo-mobile" class="img-responsive" src="<?php echo e(asset('assets/images/logo/logo-dark.png')); ?>" alt="">
                        </a>
                        <!-- Logo For ONLY Mobile display Ends -->
                        <!-- Toggle Icon for Mobile Starts -->
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <!-- Toggle Icon for Mobile Ends -->
                        <div class="collapse navbar-collapse navbar-responsive-collapse">
                            <!-- Main Menu Starts -->
                            <ul class="nav navbar-nav">

                                <li class=""><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                                 <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('menu')); ?>/<?php echo e($m->id); ?>/<?php echo e(urldecode(strtolower(str_slug($m->name)))); ?>"><?php echo e($m->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('faqs')); ?>">FAQ</a></li>
                                <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                        <?php if(Auth::check()): ?>
                        <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Hi. <?php echo e(Auth::user()->name); ?> <i class="fa fa-angle-down"></i></a>
                             <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(route('user-dashboard')); ?>">Dashboard</a></li>
                               
                         <li> <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();" class="">Log Out</a></li>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                            </ul>
                           
                        </li>
                    <?php else: ?>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Account <i class="fa fa-angle-down"></i></a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                                        <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                                    </ul>
                                </li>
                     <?php endif; ?>

                            </ul>
                            <!-- Main Menu Ends -->
                        </div>
                    </div>
                </div>
                <!-- Search Input Starts -->
                <div class="site-search">
                    <div class="container">
                        <input type="text" placeholder="type your keyword and hit enter ...">
                        <span class="close">×</span>
                    </div>
                </div>
                <!-- Search Input Ends -->
            </nav>
            <!-- Navigation Menu Ends -->
        </header>
        <!-- Header Ends -->




<!--
<nav class="main-menu wow slideInRight" data-wow-duration="2s">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="logo">
                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" style="max-height:60px;"></a>
                </div>
            </div>
            <div class="col-md-9 text-right">
                <ul id="header-menu" class="header-navigation">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('menu')); ?>/<?php echo e($m->id); ?>/<?php echo e(urldecode(strtolower(str_slug($m->name)))); ?>"><?php echo e($m->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('faqs')); ?>">Faq</a></li>
                    <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                    <?php if(Auth::check()): ?>
                        <li>
                            <a href="#">Hi. <?php echo e(Auth::user()->name); ?> <i class="fa fa-caret-down"></i></a>
                             <ul class="mega-menu mega-menu1 mega-menu2 menu-postion-4">
                                <li class="mega-list mega-list1"><a href="<?php echo e(route('user-dashboard')); ?>">Dashboard</a>
                               
                                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();" class="">Log Out</a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            </ul>
                           
                        </li>
                    <?php else: ?>
                        <li><a class="page-scroll" href="#">Account <i class="fa fa-angle-down""></i></a>
                            <ul class="mega-menu mega-menu1 mega-menu2 menu-postion-4">
                                <li class="mega-list mega-list1">
                                    <a class="page-scroll" href="<?php echo e(route('login')); ?>">Login</a>
                                    <a class="page-scroll" href="<?php echo e(route('register')); ?>">Register</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</nav>
-->
<!--main menu section end-->

<?php echo $__env->yieldContent('content'); ?>

<!-- Online Section End -->
<!--
<div class="clearfix"></div>


<div class="clearfix"></div>
-->


<!--payment method section start-->
<!--
<section class="client-section section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-header wow zoomInDown" data-wow-duration="2s">
                    <h2><span>PAYMENT METHOD </span> WE ACCEPT</h2>
                    <p><img src="<?php echo e(asset('assets/images/logo/icon.png')); ?>" alt="icon"></p>
                </div> section-heading
                <div class="section-wrapper">
                    <div class="client-list">
                         Swiper 
                        <div class="swiper-container client-container">
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = $pay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <div class="swiper-slide"><div class="our-client wow rotateIn" data-wow-duration="2s"><a href="#"><img class="img-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($p->image); ?>" alt="client"></a></div></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                         Add Arrows 
                            <div class="swiper-button-next">
                                <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                            </div>
                            <div class="swiper-button-prev">
                                <i class="fa fa-angle-double-left" aria-hidden="true"></i>
                            </div>
                        </div>client container
                    </div> client list
                </div> swiper wrapper 
            </div>

        </div>
    </div>
</section>
-->
<!--end payment method section start-->


<!-- Call To Action Section Starts -->
        <section class="call-action-all">
            <div class="call-action-all-overlay">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <!-- Call To Action Text Starts -->
                            <div class="action-text">
                                <h2>Get Started Today With Bitcoin</h2>
                                <p class="lead">Open account for free and start trading Bitcoins!</p>
                            </div>
                            <!-- Call To Action Text Ends -->
                            <!-- Call To Action Button Starts -->
                            <p class="action-btn"><a class="btn btn-primary" href="<?php echo e(url('register')); ?>">Register Now</a></p>
                            <!-- Call To Action Button Ends -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Call To Action Section Ends -->



<!--footer area start-->
<!--
<footer id="contact" class="footer-area">
  
    <div class="footer-bottom">
        <div class="footer-support-bar">
          
            <div class="footer-support-list">
                <ul>
                    <li class="wow bounceInDown" data-wow-duration="1s" data-wow-delay="1s">
                        <div class="footer-thumb"><i class="fa fa-headphones"></i></div>
                        <div class="footer-content">
                            <p>24/7 Customer Support</p>
                        </div>
                    </li>
                    <li class="wow bounceInDown" data-wow-duration="1s" data-wow-delay="2s">
                        <div class="footer-thumb"><i class="fa fa-envelope"></i></div>
                        <div class="footer-content">
                            <p><a href="<?php echo e(route('contact')); ?>"><?php echo e($basic->email); ?></a></p>
                        </div>
                    </li>
                    <li class="wow bounceInDown" data-wow-duration="1s" data-wow-delay="3s">
                        <div class="footer-thumb"><i class="fa fa-comments-o"></i></div>
                        <div class="footer-content">
                            <p>Friendly Support Ticket</p>
                        </div>
                    </li>
                    <li class="wow bounceInDown" data-wow-duration="1s" data-wow-delay="4s">
                        <div class="footer-thumb"><i class="fa fa-phone"></i></div>
                        <div class="footer-content">
                            <p><?php echo e($basic->phone); ?></p>
                        </div>
                    </li>
                </ul>
            </div>
          
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-12 wow fadeInLeft" data-wow-duration="3s">
                    <p class="copyright-text">
                       
                    </p>
                </div>
                <div class="col-md-4 col-sm-9 wow bounceInDown" data-wow-duration="3s">
                    <p class="copyright-text">
                        <?php echo $basic->copy_text; ?>

                    </p>
                </div>
                <div class="col-md-4 col-sm-3 wow fadeInRight" data-wow-duration="3s">
                    
                </div>
            </div>
        </div>
    </div>
    <div id="back-to-top" class="scroll-top back-to-top" data-original-title="" title="" >
        <i class="fa fa-angle-up"></i>
    </div>
</footer>
-->


 <!-- Footer Starts -->
        <footer class="footer">
            <!-- Footer Top Area Starts -->
            <div class="top-footer">
                <div class="container">
                    <div class="row">
                        <!-- Footer Widget Starts -->
                        <div class="col-sm-4 col-md-2">
                            <h4>Our Company</h4>
                            <div class="menu">
                                <ul>
                                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                    <li><a href="<?php echo e(route('about')); ?>">About</a></li>
                                    <li><a href="<?php echo e(route('home')); ?>/#plan">Plans</a></li>
                                    <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- Footer Widget Ends -->
                        <!-- Footer Widget Starts -->
                        <div class="col-sm-4 col-md-2">
                            <h4>Help & Support</h4>
                            <div class="menu">
                                <ul>
                                    <li><a href="<?php echo e(route('faqs')); ?>">FAQ</a></li>
                                    <li><a href="<?php echo e(route('about')); ?>">Terms of Services</a></li>
                                    
                                    <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                                    <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- Footer Widget Ends -->
                        <!-- Footer Widget Starts -->
                        <div class="col-sm-4 col-md-3">
                            <h4>Contact Us </h4>
                            <div class="contacts">
                                <div>
                                    <span><?php echo e($basic->email); ?></span>
                                </div>
                                <div>
                                    <span><?php echo e($basic->phone); ?></span>
                                </div>
                                <div>
                                    <span><?php echo e($basic->address); ?></span>
                                </div>
                                
                            </div>
                            <!-- Social Media Profiles Starts -->
                            <div class="social-footer">
                                <ul>
                                    <li><a href="#" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                </ul>
                            </div>
                            <!-- Social Media Profiles Ends -->
                        </div>
                        <!-- Footer Widget Ends -->
                        <!-- Footer Widget Starts -->
                        <div class="col-sm-12 col-md-5">
                            <!-- Facts Starts -->
                            <div class="facts-footer">
                                <div>
                                    <h5>$198.76B</h5>
                                    <span>Market cap</span>
                                </div>
                                <div>
                                    <h5>243K</h5>
                                    <span>daily transactions</span>
                                </div>
                                <div>
                                    <h5>369K</h5>
                                    <span>active accounts</span>
                                </div>
                                <div>
                                    <h5>127</h5>
                                    <span>supported countries</span>
                                </div>
                            </div>
                            <!-- Facts Ends -->
                            <hr>
                            <!-- Supported Payment Cards Logo Starts -->

                            <div class="payment-logos">
                                <h4 class="payment-title">supported payment methods</h4>
                                <img  src="<?php echo e(asset('assets/images/icons/payment/american-express.png')); ?>" alt="american-express">
                                <img  src="<?php echo e(asset('assets/images/icons/payment/mastercard.png')); ?>" alt="mastercard">
                                <img  src="<?php echo e(asset('assets/images/icons/payment/visa.png')); ?>" alt="visa">
                                <img  src="<?php echo e(asset('assets/images/icons/payment/paypal.png')); ?>" alt="paypal">
                                <img class="last"  src="<?php echo e(asset('assets/images/icons/payment/maestro.png')); ?>" alt="maestro">
                            </div>
                            <!-- Supported Payment Cards Logo Ends -->
                        </div>
                        <!-- Footer Widget Ends -->
                    </div>
                </div>
            </div>
            <!-- Footer Top Area Ends -->
            <!-- Footer Bottom Area Starts -->
            <div class="bottom-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <!-- Copyright Text Starts -->
                            <p class="text-center"><?php echo $basic->copy_text; ?></p>
                            <!-- Copyright Text Ends -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Bottom Area Ends -->
        </footer>
        <!-- Footer Ends -->
        <!-- Back To Top Starts  -->
        <a href="#" id="back-to-top" class="back-to-top fa fa-arrow-up"></a>
        <!-- Back To Top Ends  -->

 <!-- Template JS Files -->
    <script src="<?php echo e(asset('assets/front/newjs/jquery-2.2.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/newjs/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/newjs/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/newjs/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/front/newjs/custom.js')); ?>"></script>

     <script src="<?php echo e(asset('assets/admin/js/sweetalert.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('script'); ?>
<!--Main js file load-->
<script src="<?php echo e(asset('assets/front/js/main.js')); ?>"></script>

<script src="<?php echo e(asset('assets/front/2/js/main.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script> -->
<!--swal alert message-->
<?php if(session('success')): ?>
    <script type="text/javascript">
        $(document).ready(function(){
            swal("Success!", "<?php echo e(session('success')); ?>", "success");
        });
    </script>
<?php endif; ?>
<?php if(session('alert')): ?>
    <script type="text/javascript">
        $(document).ready(function(){
            swal("Sorry!", "<?php echo e(session('alert')); ?>", "error");
        });
    </script>
<?php endif; ?>
<?php if(session('error')): ?>
    <script type="text/javascript">
        $(document).ready(function(){
            swal("Sorry!", "<?php echo e(session('error')); ?>", "error");
        });
    </script>
<?php endif; ?>

<!--end swal alert message-->
<script>
var mobile = (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent));

hljs.initHighlightingOnLoad();
hljs.configure({useBR: true});
jQuery('#raindrops').raindrops({color:'#fff',canvasHeight:5});
jQuery('#raindrops-green').raindrops({color:'#<?php echo e($basic->color); ?> ',canvasHeight:5});

</script>
</body>
</html>