
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.breadcam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content_padding">
    <div class="container user-dashboard-body">
    <div class="row">
        <div class="login-admin login-admin1">
            <div class="login-header text-center">
                <h6>change password</h6>
            </div>
        
            <div class="col-md-6 col-md-offset-3">
                <!-- BEGIN SAMPLE FORM PORTLET-->
                    <form action="" method="post" role="form">
                        <?php echo csrf_field(); ?>

                    <input name="current_password" placeholder="Current Password" type="password">
                    <input name="password" placeholder="New Password" type="password">
                    <input name="password_confirmation" placeholder="New Password Again" type="password">
                    <button type="submit" class="new-btn-submit">Change Password</button>   
                    </form>
            </div>
        </div><!---ROW-->
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php if(session('message')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Success!", "<?php echo e(session('message')); ?>", "success");

            });

        </script>

    <?php endif; ?>



    <?php if(session('alert')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Sorry!", "<?php echo e(session('alert')); ?>", "error");

            });

        </script>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>