
<?php $__env->startSection('content'); ?>
    <!-- Banner Area Starts -->
        <section class="banner-area">
      <div class="banner-overlay">
        <div class="banner-text text-center">
          <div class="container">
            <!-- Section Title Starts -->
            <div class="row text-center">
              <div class="col-xs-12">
                <!-- Title Starts -->
                <h2 class="title-head">Get in <span>touch</span></h2>
                <!-- Title Ends -->
                <hr>
                <!-- Breadcrumb Starts -->
                <ul class="breadcrumb">
                  <li><a href="<?php echo e(route('home')); ?>"> home</a></li>
                  <li>contact</li>
                </ul>
                <!-- Breadcrumb Ends -->
              </div>
            </div>
            <!-- Section Title Ends -->
          </div>
        </div>
      </div>
        </section>
        <!-- Banner Area Ends -->

        <!-- Contact Section Starts -->
        <section class="contact">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-md-8 contact-form">
            <h3 class="col-xs-12">feel free to drop us a message</h3>
                        <p class="col-xs-12">Need to speak to us? Do you have any queries or suggestions? Please contact us about all enquiries including membership and volunteer work using the form below.</p>

                          <?php if($errors->any()): ?>
                            
                                <div class=" alert text-danger alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $error; ?>

                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                           
                        <?php endif; ?>
                        <?php if(session()->has('message')): ?>
                            <div class="alert text-<?php echo e(session()->get('type')); ?> alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>
                        <!-- Contact Form Starts -->
                        <form action="<?php echo e(route('contact-submit')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                            <!-- Input Field Starts -->
                            <div class="form-group col-md-6">
                                <input class="form-control" name="name" id="firstname" placeholder="FIRST NAME" type="text" required>
                            </div>
                            <!-- Input Field Ends -->
                            <!-- Input Field Starts -->
                            <div class="form-group col-md-6">
                                <input class="form-control" name="phone" id="phone" placeholder="Phone Number" type="text" required>
                            </div>
                            <!-- Input Field Ends -->
                            <!-- Input Field Starts -->
                            <div class="form-group col-md-6">
                                <input class="form-control" name="email" id="email" placeholder="EMAIL" type="email" required>
                            </div>
                            <!-- Input Field Ends -->
                            <!-- Input Field Starts -->
                            <div class="form-group col-md-6">
                                <input class="form-control" name="subject" id="subject" placeholder="SUBJECT" type="text" required>
                            </div>
                            <!-- Input Field Ends -->
                            <!-- Input Field Starts -->
                            <div class="form-group col-xs-12">
                                <textarea class="form-control" id="message" name="message" placeholder="MESSAGE" required></textarea>
                            </div>
                            <!-- Input Field Ends -->
                            <!-- Submit Form Button Starts -->
                            <div class="form-group col-xs-12 col-sm-4">
                                <button class="btn btn-primary btn-contact" name="submit-form" type="submit">send message</button>
                            </div>
                            <!-- Submit Form Button Ends -->
                            <!-- Form Submit Message Starts -->
                            <div class="col-xs-12 text-center output_message_holder d-none">
                <p class="output_message"></p>
                            </div>
                             <!-- Form Submit Message Ends -->
                        </form>
            <!-- Contact Form Ends -->
                    </div>
          <!-- Contact Widget Starts -->
                    <div class="col-xs-12 col-md-4">
                        <div class="widget">
                            <div class="contact-page-info">
                <!-- Contact Info Box Starts -->
                                <div class="contact-info-box">
                                    <i class="fa fa-home big-icon"></i>
                                    <div class="contact-info-box-content">
                                        <h4>Address</h4>
                                        <p><?php echo e($basic->address); ?></p>
                                    </div>
                                </div>
                <!-- Contact Info Box Ends -->
                <!-- Contact Info Box Starts -->
                                <div class="contact-info-box">
                                    <i class="fa fa-phone big-icon"></i>
                                    <div class="contact-info-box-content">
                                        <h4>Phone Numbers</h4>
                                        <p><?php echo e($basic->phone); ?></p>
                                    </div>
                                </div>
                <!-- Contact Info Box Ends -->
                <!-- Contact Info Box Starts -->
                                <div class="contact-info-box">
                                    <i class="fa fa-envelope big-icon"></i>
                                    <div class="contact-info-box-content">
                                        <h4>Email Addresses</h4>

                                        <p><?php echo e($basic->email); ?></p>
                                    </div>
                                </div>
                <!-- Contact Info Box Ends -->
                            </div>
                        </div>
                    </div>
          <!-- Contact Widget Ends -->
                </div>
            </div>
        </section>
        <!-- Contact Section Ends -->

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.newfrontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>