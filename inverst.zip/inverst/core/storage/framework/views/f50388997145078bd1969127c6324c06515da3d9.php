<?php $__env->startSection('style'); ?>

   <link rel="stylesheet" href="<?php echo e(asset('assets/css/ion.rangeSlider.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('assets/css/ranger-style.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('assets/css/ion.rangeSlider.skinFlat.css')); ?>">
    <style>
       .price-table {
            margin-bottom: 45px;
   </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--Header section start-->
    <section id="particles-js" class="header-area header-bg" style="background-image: url('<?php echo e(asset('assets/images/slider')); ?>/<?php echo e($slider_text->image); ?>')">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 text-center">
                    <div class="header-section-wrapper">
                        <div class="header-section-top-part">
                            <div class="text-first wow slideInLeft" data-wow-duration="2s"><?php echo $slider_text->title; ?></div>
                            <p style="font-size: 1.5em;" class=" wow slideInDown" data-wow-duration="2s"><?php echo $slider_text->subtitle; ?></p>
                        </div>
                        <div class="header-section-bottom-part">
                            <div class="domain-search-from">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Header section end-->
    <div class="clearfix"></div>
    <!-- Admin section start -->
    <div class="admin-section wow slideInRight" data-wow-duration="2s">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- admin content start -->
                    <div class="admin-content">
                        <!-- admin text start -->
                        <div class="admin-text">
                            <p>Get access to Your account</p>
                        </div>
                        <!-- admin text end -->
                        <!-- admin user start -->
                        <div class="admin-user">
                            <a href="<?php echo e(url('login')); ?>"><button type="submit" name="login">sign in</button></a>
                            <a href="<?php echo e(url('register')); ?>"><button type="submit" name="register">register now</button></a>
                        </div>
                        <!-- admin user end -->
                    </div>
                    <!-- admin-content end -->
                </div>
            </div>
        </div>
    </div>
    <!-- Admin section end -->

    <div class="clearfix"></div>
    <!-- Circle Section Start -->
    <section  class="circle-section section-padding wow slideInUp" data-wow-duration="2s">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-header">
                        <h2>HOW <span> <?php echo e($basic_setting->title); ?> </span> Works </h2>
                        <p><img src="<?php echo e(asset('assets/images/logo/icon.png')); ?>" alt="icon"></p>
                    </div>
                </div>
            </div>

            <div class="row">
                <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <div class="circle-item wow flipInY" data-wow-duration="2s">
                            <img src="<?php echo e(asset('assets/images/features')); ?>/<?php echo e($feature->photo); ?>" alt="items">
                            <div class="circle-content">
                                <h6><?php echo e($feature->title); ?></h6>
                                <p><?php echo e($feature->description); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Circle Section End -->
<div class="clearfix"></div>

<!--About community Section Start-->
<section class="section-padding sale-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <div class="sale-header wow slideInDown" data-wow-duration="2s">
                        <h2>about <span> <?php echo e($site_title); ?> </span></h2>
                    </div>
                    <div class="sale-content">
                         <div class="row">
                            <div class="col-md-6 wow slideInLeft" data-wow-duration="2s">
                                <p class="about-community-text">
                                    <?php echo $page->about_leftText; ?>

                                </p>
                            </div>
                            <div class="col-md-6 wow slideInRight" data-wow-duration="2s">
                                <p class="about-community-text text-justify">
                                    <?php echo $page->about_rightText; ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--About community Section end-->
<div class="clearfix"></div>
<!--service section start-->
<section class="service-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center section-padding padding-bottom-0 wow slideInLeft" data-wow-duration="2s">
                    <div class="section-header">
                        <h2>Our <span>Services</span></h2>
                        <p><img src="<?php echo e(asset('assets/images/logo/icon.png')); ?>" alt="icon"></p>
                    </div>
                    <p><?php echo $page->service_subtitle; ?></p>
                </div>
            </div>
        </div>
        <div class="row wow slideInRight" data-wow-duration="2s">
            <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6">
                <div class="service-wrapper text-center">
                    <div class="service-icon ">
                        <?php echo $s->code; ?>

                    </div>
                    <div class="service-title">
                        <p><?php echo e($s->title); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!--service section end-->

    <!--start investment plan-->
    <section class="section-background">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title text-center section-padding padding-bottom-0 wow slideInLeft" data-wow-duration="2s">
                        <div class="section-header">
                            <h2>Our awesome <span> plans</span></h2>
                            <p><img src="<?php echo e(asset('assets/images/logo/icon.png')); ?>" alt="icon"></p>
                        </div>
                        <p><?php echo $page->plan_subtitle; ?></p>
                    </div>
                </div>
            </div>

            <div class="row">
                <?php $__currentLoopData = $plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6 pricing-list-botom-margin wow zoomIn" data-wow-duration="3s">
                        <!-- Pricing  List1 Start -->
                        <div class="pricing-list1">
                            <div class="pricing-header1">
                                <h5><?php echo e($p->name); ?></h5>
                                <p><?php echo e($p->compound->name); ?> <?php echo e($p->percent); ?>% for <?php echo e($p->time); ?> times</p>
                            </div>
                            <div class="pricing-info1">
                                <ul>
                                    <li> <p>for <span class="color-text"><?php echo e($p->time); ?></span> times</p></li>
                                    <li><p> <span class="color-text"><?php echo e($p->percent); ?>%</span> roi each time</p></li>
                                </ul>
                            </div>
                            <div class="price-range">
                                            <div class="row">
                                                <div class="col-md-6 text-left col-sm-6 col-xs-6">
                                                    <div class="min-price">
                                                        <h6>Minimum<span class="color-text"><?php echo e($basic->symbol); ?> <?php echo e($p->minimum); ?></span></h6>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 text-right col-sm-6 col-xs-6">
                                                    <div class="min-price">
                                                        <h6>Maximum<span class="color-text"><?php echo e($basic->symbol); ?> <?php echo e($p->maximum); ?></span></h6>
                                                    </div>
                                                </div>
                                            </div>
                            </div>
                            <div class="invest-type__profit plan__value--<?php echo e($p->id); ?>">
                                <input type="text" value="<?php echo e($basic->symbol); ?> <?php echo e(($p->minimum + $p->maximum) / 2); ?>" class="custom-input invest-type__profit--val" data-slider=".slider-input--<?php echo e($p->id); ?>" style="color:#FFF; font-size: 25px">
                                <input type="hidden" name="amount" value="<?php echo e(($p->minimum + $p->maximum) / 2); ?>" class=" slider-input slider-input--<?php echo e($p->id); ?>" data-perday="<?php echo e($p->percent); ?>" data-peryear="<?php echo e($p->time); ?>" data-min="<?php echo e($p->minimum); ?>" data-max="<?php echo e($p->maximum); ?>" data-dailyprofit=".daily-profit-<?php echo e($p->id); ?>" data-totalprofit=".total-profit-<?php echo e($p->id); ?> " data-valuetag=".plan__value--<?php echo e($p->id); ?> .invest-type__profit--val"/>
                            </div>
                            <input type="hidden" name="plan_id" value="<?php echo e($p->id); ?>">
                            <div class="price-range">
                                <div class="row">
                                    <div class="col-md-6 text-left col-sm-6 col-xs-6 invest-type__calc invest-type__calc--daily">
                                        <div class="min-price">
                                            <h6>per time<span class="color-text"><b class="daily-profit-<?php echo e($p->id); ?>"><?php echo e($basic->symbol); ?> <?php echo e((($p->minimum + $p->maximum) / 2 ) * $p->percent /100); ?>.0</b></span></h6>
                                        </div>
                                    </div>
                                    <div class="col-md-6 text-right col-sm-6 col-xs-6 invest-type__calc invest-type__calc--total">
                                        <div class="min-price">
                                            <h6>Total Return<span class="color-text"><b class="total-profit-<?php echo e($p->id); ?>"><?php echo e($basic->symbol); ?> <?php echo e((((($p->minimum + $p->maximum) / 2) * $p->percent) /100 ) * $p->time); ?>.0</b></span></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!--<a href="pricing-list.html">Order Now!</a>-->
                        </div>
                        <!-- Pricing List1 End -->
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <div class="row section-padding padding-bottom-0">
            <div class="col-md-6 col-sm-6">
                <div class="contact-middel-info wow bounceInLeft" data-wow-duration="2s">
                    <div class="contact-middel-title">
                        <h4>Have a question <span>we are here to help!</span></h4>
                    </div>
                    <div class="contact-middel-details">
                        <p><i class="fa fa-phone"></i> <?php echo e($basic->phone); ?></p>
                        <p><i class="fa fa-envelope"></i> <?php echo e($basic->email); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-sm-6">
                <div class="discunt-middel-text wow bounceInRight" data-wow-duration="2s">
                    <h3><?php echo e($basic->reference_percent); ?><i class="fa fa-percent"></i> <br /> referral <br /> commission</h3>
                </div>
            </div>
        </div>
        </div>
</section>
<!--end start investment plan-->
<!--Our Top Investor Section Start-->
<div class="clearfix"></div>
<section class="commission-section section-padding ">
    <div class="container">
      <!-- section header start -->
          <div class="section-header wow slideInLeft" data-wow-duration="2s">
            <h2>Our top <span> Investors</span></h2>
            <p><img src="<?php echo e(asset('assets/images/logo/icon.png')); ?>" alt="icon"></p>
          </div>
           <p class="margin-b-35 wow slideInRight" data-wow-duration="2s"><?php echo e($page->investor_subtitle); ?></p>
        <!-- section header end -->
      <div class="row">
        <?php $i=1 ?>
        <?php $__currentLoopData = $top_investor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
          <div class="referral-amount wow zoomIn" data-wow-duration="3s">
            <p><?php echo e(\App\User::findOrFail($inv->user_id)->name); ?></p>
            <h4><span> <?php echo e($basic->symbol); ?> </span><?php echo e(number_format($inv->total_invest)); ?></h4>
            <h5><?php echo e($i++); ?></h5>
          </div>
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section>
<!--Our Top Investor Section Start-->

<div class="clearfix"></div>
<!--staticies sectioin-->
<section class="sale-section section-padding">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <!-- Counter List -->
            <div class="counter-list wow shake" data-wow-duration="2s">
              <!-- Counter Item -->
              <div class="counter-item">
                <div class="counter-thumb"><i class="fa fa-user"></i><p class="counter"><?php echo e($total_user); ?></p></div>
                  <div class="counter-content">
                      <p>Total User</p>
                  </div>
              </div>
              <!-- Counter Item -->
            </div>
            <!-- Counter List -->
          </div>
          <div class="col-md-3">
            <!-- Counter List -->
            <div class="counter-list wow shake" data-wow-duration="2s" data-wow-delay="2s">
              <!-- Counter Item -->
              <div class="counter-item">
                <div class="counter-thumb"> <i class="fa fa-recycle"></i><p class="counter"><?php echo e($total_repeat); ?></p></div>
                  <div class="counter-content">
                   <p>Total Repeat</p>
                  </div>
              </div>
              <!-- Counter Item -->
            </div>
            <!-- Counter List -->
          </div>
          <div class="col-md-3">
            <!-- Counter List -->
            <div class="counter-list wow shake" data-wow-duration="2s" data-wow-delay="4s">
              <!-- Counter Item -->
              <div class="counter-item">
                <div class="counter-thumb"> <i class="fa fa-cloud-download"></i><p class="counter"><?php echo e($total_deposit); ?></p></div>
                  <div class="counter-content">
                     <p>Total Deposit</p>
                  </div>
              </div>
              <!-- Counter Item -->
            </div>
            <!-- Counter List -->
          </div>
          <div class="col-md-3">
            <!-- Counter List -->
            <div class="counter-list wow shake" data-wow-duration="2s" data-wow-delay="6s">
              <!-- Counter Item -->
              <div class="counter-item">
                <div class="counter-thumb"><i class="fa fa-cloud-upload"></i><p class="counter"><?php echo e($total_withdraw); ?></p></div>
                  <div class="counter-content">
                    <p>Total Withdraw</p>
                  </div>
              </div>
              <!-- Counter Item -->
            </div>
            <!-- Counter List -->
          </div>
        </div>
      </div>
 </section>
<!--staticies sectioin end-->
<div class="clearfix"></div>
<!--testimonial section start-->
    <section class="people-say-section section-padding">
      <div class="container">
       <div class="row">
        <div class="col-md-12">
          <!-- section header start -->
          <div class="section-header wow bounceInLeft" data-wow-duration="2s">
            <h2>What People <span>Say</span> </h2>
           <p><img src="<?php echo e(asset('assets/images/logo/icon.png')); ?>" alt="icon"></p>
          </div>
        <!-- section header end -->
        </div>
      </div>
        <div class="row">
          <div class="col-md-12">   

              <div class="testimonial-area">
                <div class="row">
                    <div class="col-lg-12  col-md-10 ">
                      <div class="row">
                        <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-2">
                          <div class="testimonial-image-slider slider-nav text-center">
                          <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <div class="sin-testiImage wow rotateIn" data-wow-duration="2s">
                              <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($tes->image); ?>" alt="slider">
                            </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                        </div>
                  </div>
                      </div> 

                </div>  
                  <div class="row">
                  <div class="col-md-12 ">
                      <div class="testimonial-text-slider slider-for text-center wow bounceInRight" data-wow-duration="2s">
                         <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <div class="sin-testiText">
                                 <!-- people sat content list start -->
                                  <div class="people-say-content-list  " >
                                    <h4><?php echo e($tes->name); ?></h4>

                                    <h6><?php echo e($tes->position); ?></h6>
                                    <ul>
                                        <li>
                                          <i class="fa fa-star" aria-hidden="true"></i>
                                        </li>
                                        <li>
                                          <i class="fa fa-star" aria-hidden="true"></i>
                                        </li>
                                        <li>
                                          <i class="fa fa-star" aria-hidden="true"></i>
                                        </li>
                                        <li>
                                          <i class="fa fa-star" aria-hidden="true"></i>
                                        </li>
                                        <li>
                                          <i class="fa fa-star" aria-hidden="true"></i>
                                        </li>
                                    </ul>
                                    <p>
                                        <?php echo $tes->message; ?> 
                                    </p>
                                  </div>
                                  <!-- people-say-content-list end -->
                            </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </div> 
                  </div>
                  </div>
                </div>
              </div>

          </div>

        </div><!-- row -->
    </section><!--  section -->
<!--testimonial section start-->
<div class="clearfix"></div>
 <!--Deopsit and Payouts section start-->
<section class="hosting-section hosting-section1  section-padding section-background">
      <div class="container">
                  <div class="row">
        <div class="col-md-12">
          <!-- section header start -->
          <div class="section-header wow bounceInDown" data-wow-duration="3s">
            <h2>Latest <span> Deposits & Withdraw</span></h2>
             <p><img src="<?php echo e(asset('assets/images/logo/icon.png')); ?>" alt="icon"></p>
          </div>
        <!-- section header end -->
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
              <div class="section-wrapper wow bounceInLeft" data-wow-duration="2s">
                 <div class="deposit-title text-center">
                        <h4>Latest Deposits</h4>
                    </div>
                <div class="hosting-content table-responsive">
                  <table>
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Date</th>
                        <th>Currency</th>
                         <th>Amount</th>
                      </tr>
                      
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $latest_deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ld->member->name); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($ld->created_at)->format('M d,Y')); ?></td>
                                <td><strong><?php echo e($basic->currency); ?></strong></td>
                                <td><strong><?php echo e($basic->symbol); ?><?php echo e($ld->amount); ?></strong></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <!-- hosting content end -->
              </div>
            </div>
                    <div class="col-md-6">
              <div class="section-wrapper wow bounceInRight" data-wow-duration="2s">
                  <div class="deposit-title text-center">
                        <h4>Latest Withdraw</h4>
                    </div>
                <div class="hosting-content table-responsive">
                  <table>
                    <thead>
                      <tr>
                         <th>Name</th>
                         <th>Date</th>
                         <th>Currency</th>
                         <th>Amount</th>
                      </tr>
                      
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $latest_withdraw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($ld->user->name); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($ld->created_at)->format('M d,Y')); ?></td>
                            <td><strong><?php echo e($basic->currency); ?></strong></td>
                            <td><strong><?php echo e($basic->symbol); ?><?php echo e($ld->amount); ?></strong></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <!-- hosting content end -->
              </div>
            </div>
        </div><!-- row -->
      </div><!-- container -->
    </section>
<!--Deopsit and Payouts Section End-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/ion.rangeSlider.js')); ?>"></script>
    <script type="text/javascript">
        $(window).load(function() {
            var wow = new WOW({
                boxClass: 'wow',
                animateClass: 'animated',
                offset: 0,
                mobile: true,
                live: true
            });
            wow.init();
        });
    </script>
    <script>
        $.each($('.slider-input'), function() {
            var $t = $(this),

                    from = $t.data('from'),
                    to = $t.data('to'),

                    $dailyProfit = $($t.data('dailyprofit')),
                    $totalProfit = $($t.data('totalprofit')),

                    $val = $($t.data('valuetag')),

                    perDay = $t.data('perday'),
                    perYear = $t.data('peryear');


            $t.ionRangeSlider({
                input_values_separator: ";",
                prefix: '<?php echo e($basic->symbol); ?> ',
                hide_min_max: true,
                force_edges: true,
                onChange: function(val) {
                    $val.val( '<?php echo e($basic->symbol); ?> ' + val.from);

                    var profit = (val.from * perDay / 100).toFixed(1);
                    profit  = '<?php echo e($basic->symbol); ?> ' + profit.replace('.', '.') ;
                    $dailyProfit.text(profit) ;

                    profit = ( (val.from * perDay / 100)* perYear ).toFixed(1);
                    profit  =  '<?php echo e($basic->symbol); ?> ' + profit.replace('.', '.');
                    $totalProfit.text(profit);

                }
            });
        });
        $('.invest-type__profit--val').on('change', function(e) {

            var slider = $($(this).data('slider')).data("ionRangeSlider");

            slider.update({
                from: $(this).val().replace('<?php echo e($basic->symbol); ?> ', "")
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.newfrontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>